﻿namespace Lab1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.myImagePBox = new System.Windows.Forms.PictureBox();
            this.nameLbl = new System.Windows.Forms.Label();
            this.hobbiesBtn = new System.Windows.Forms.Button();
            this.bookBtn = new System.Windows.Forms.Button();
            this.movieBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.myImagePBox)).BeginInit();
            this.SuspendLayout();
            // 
            // myImagePBox
            // 
            this.myImagePBox.Image = global::Lab1.Properties.Resources.alwrig01;
            this.myImagePBox.Location = new System.Drawing.Point(67, 12);
            this.myImagePBox.Name = "myImagePBox";
            this.myImagePBox.Size = new System.Drawing.Size(150, 150);
            this.myImagePBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.myImagePBox.TabIndex = 0;
            this.myImagePBox.TabStop = false;
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Location = new System.Drawing.Point(98, 169);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(89, 13);
            this.nameLbl.TabIndex = 1;
            this.nameLbl.Text = "Andrew L. Wright";
            // 
            // hobbiesBtn
            // 
            this.hobbiesBtn.Location = new System.Drawing.Point(23, 211);
            this.hobbiesBtn.Name = "hobbiesBtn";
            this.hobbiesBtn.Size = new System.Drawing.Size(75, 23);
            this.hobbiesBtn.TabIndex = 2;
            this.hobbiesBtn.Text = "Hobbies";
            this.hobbiesBtn.UseVisualStyleBackColor = true;
            this.hobbiesBtn.Click += new System.EventHandler(this.hobbiesBtn_Click);
            // 
            // bookBtn
            // 
            this.bookBtn.Location = new System.Drawing.Point(105, 210);
            this.bookBtn.Name = "bookBtn";
            this.bookBtn.Size = new System.Drawing.Size(75, 23);
            this.bookBtn.TabIndex = 3;
            this.bookBtn.Text = "Book";
            this.bookBtn.UseVisualStyleBackColor = true;
            this.bookBtn.Click += new System.EventHandler(this.bookBtn_Click);
            // 
            // movieBtn
            // 
            this.movieBtn.Location = new System.Drawing.Point(187, 211);
            this.movieBtn.Name = "movieBtn";
            this.movieBtn.Size = new System.Drawing.Size(75, 23);
            this.movieBtn.TabIndex = 4;
            this.movieBtn.Text = "Movie";
            this.movieBtn.UseVisualStyleBackColor = true;
            this.movieBtn.Click += new System.EventHandler(this.movieBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.movieBtn);
            this.Controls.Add(this.bookBtn);
            this.Controls.Add(this.hobbiesBtn);
            this.Controls.Add(this.nameLbl);
            this.Controls.Add(this.myImagePBox);
            this.Name = "Form1";
            this.Text = "Lab 1";
            ((System.ComponentModel.ISupportInitialize)(this.myImagePBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox myImagePBox;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Button hobbiesBtn;
        private System.Windows.Forms.Button bookBtn;
        private System.Windows.Forms.Button movieBtn;
    }
}

