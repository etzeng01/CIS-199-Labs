﻿// Lab 1
// CIS 199-01/-75
// Due: 1/26/2016
// By: Andrew L. Wright

// This program displays an image of the author with their
// name and 3 buttons. One button displays the author's
// hobbies, one displays the author's favorite book, and
// one displays the author's favorite movie.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Displays list of hobbies
        private void hobbiesBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("My hobbies include playing tennis and reading.");
        }

        // Displays favorite book
        private void bookBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("My favorite book is The Hobbit.");
        }

        // Displays favorite movie
        private void movieBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("My favorite movie is The Matrix.");
        }       
    }
}
