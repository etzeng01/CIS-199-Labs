﻿// Lab 4
// CIS 199-01/-75
// Due: 2/16/2016
// By: Andrew L. Wright

// This program makes an admission decision based on a student's
// high school GPA and admission test score. A student is accepted
// if the student meets either of the following requirements:
// -  A grade point average of 3.0 or higher and an admission test score of at least 60
// -  A grade point average of less than 3.0 and an admission test score of at least 80
// If the student does not meet either of the qualification criteria, then they
// are rejected.
// Running counts of number of applicants accepted/rejected are maintained.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab4_GUI
{
    public partial class AdmissionForm : Form
    {
        private uint numAccepted = 0; // Total applicants accepted
        private uint numRejected = 0; // Total applicants rejected

        public AdmissionForm()
        {
            InitializeComponent();
        }

        private void admitBtn_Click(object sender, EventArgs e)
        {
            const double GPA_THRESH = 3.0; // GPA where decision rules change
            const uint LOW_SCORE = 60;     // Admission score needed with high GPA
            const uint HIGH_SCORE = 80;    // Admission score needed with lower GPA

            double gpa;     // Entered GPA, valid 0.0 - 4.0
            uint testScore; // Entered test score, valid >= 0 (implied by type)
            bool accepted;  // Was applicant accepted or not?

            // Parse input from user
            gpa = double.Parse(gpaTxt.Text);
            testScore = uint.Parse(scoreTxt.Text);

            // Make admission decision
            if ((gpa >= GPA_THRESH) && (testScore >= LOW_SCORE))
                accepted = true;
            else if ((gpa < GPA_THRESH) && (testScore >= HIGH_SCORE))
                accepted = true;
            else
                accepted = false;

            // You can comment out a whole block at a time
            // or uncomment out a whole block at a time
            // using the Text Editor toolbar or by
            // typing CTRL-E, C - to comment selected block
            // typing CTRL-E, U - to uncomment selected block

            // OR

            //if (testScore >= HIGH_SCORE) // Automatic admission?
            //    accepted = true;
            //else if ((gpa >= GPA_THRESH) && (testScore >= LOW_SCORE))
            //    accepted = true;
            //else
            //    accepted = false;

            // OR

            //if ((gpa >= GPA_THRESH) && (testScore >= LOW_SCORE) ||
            //    (gpa < GPA_THRESH) && (testScore >= HIGH_SCORE))
            //    accepted = true;
            //else
            //    accepted = false;

            // OR

            //if (gpa >= GPA_THRESH)
            //    if (testScore >= LOW_SCORE)
            //        accepted = true;
            //    else
            //        accepted = false;
            //else
            //    if (testScore >= HIGH_SCORE)
            //        accepted = true;
            //    else
            //        accepted = false;

            if (accepted)
            {
                decisionLbl.Text = "Accept";
                numAccepted += 1; // Increment counter
                numAcceptedLbl.Text = numAccepted.ToString();
            }
            else
            {
                decisionLbl.Text = "Reject";
                numRejected += 1; // Increment counter
                numRejectedLbl.Text = numRejected.ToString();
            }
        }
    }
}
