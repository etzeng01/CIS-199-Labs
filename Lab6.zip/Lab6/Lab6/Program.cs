﻿// Lab 6
// CIS 199-01/-75
// Due: 3/8/2016
// By: Andrew L. Wright

// File: Program.cs
// This file demonstrates the use of nested loops to produce
// 4 sets of patterns made up of asterisks.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        const int MAX_ROWS = 10; // Number of rows in each pattern

        Console.WriteLine("Pattern A\n");

        for (int row = 1; row <= MAX_ROWS; row++) // row is also # of stars on line
        {
            for (int star = 1; star <= row; star++)
                Console.Write("*");

            Console.WriteLine();
        }

        Console.WriteLine("\nPattern B\n");

        for (int row = MAX_ROWS; row >= 1; row--) // row is also # of stars on line
        {
            for (int star = 1; star <= row; star++)
                Console.Write("*");

            Console.WriteLine();
        }

        Console.WriteLine("\nPattern C\n");

        for (int row = MAX_ROWS; row >= 1; row--) // row is also # of stars on line
        {
            // Need (MAX_ROWS - row) # of spaces first
            for (int space = 1; space <= MAX_ROWS - row; space++)
                Console.Write(" ");

            for (int star = 1; star <= row; star++)
                Console.Write("*");

            Console.WriteLine();
        }

        Console.WriteLine("\nPattern D\n");

        for (int row = 1; row <= MAX_ROWS; row++) // row is also # of stars on line
        {
            // Need (MAX_ROWS - row) # of spaces first
            for (int space = 1; space <= MAX_ROWS - row; space++)
                Console.Write(" ");

            for (int star = 1; star <= row; star++)
                Console.Write("*");

            Console.WriteLine();
        }
    }
}
