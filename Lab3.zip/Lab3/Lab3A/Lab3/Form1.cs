﻿// Lab 3
// CIS 199-01/-75
// Due: 2/9/2016
// By: Andrew L. Wright

// Alternate Solution

// This program prompts the user for the price of a meal
// and then calculates 3 different tip amounts, 15%,
// 18%, and 20%. This version uses the Form's Load event
// to programmatically change the tip label controls.
// Also has set the Form's AcceptButton property, so 
// can hit enter in textbox and cause calcTipBtn
// to be clicked.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        private const decimal TIPRATE1 = 0.15m; // 15% rate
        private const decimal TIPRATE2 = 0.18m; // 18% rate
        private const decimal TIPRATE3 = 0.20m; // 20% rate

        public Form1()
        {
            InitializeComponent();
        }

        // Calculate and display tips
        private void calcTipBtn_Click(object sender, EventArgs e)
        {
            decimal price; // Price of meal
            decimal tip1;  // Tip amount for rate 1
            decimal tip2;  // Tip amount for rate 2
            decimal tip3;  // Tip amount for rate 3

            // Convert input into decimal
            price = decimal.Parse(priceTxt.Text);

            // Calculate tip amounts
            tip1 = TIPRATE1 * price;
            tip2 = TIPRATE2 * price;
            tip3 = TIPRATE3 * price;

            // Display tip amounts
            tip1Lbl.Text = tip1.ToString("C");
            tip2Lbl.Text = tip2.ToString("C");
            tip3Lbl.Text = tip3.ToString("C");
        }

        // Add the tip rates into labels on form load
        private void Form1_Load(object sender, EventArgs e)
        {
            rate1Lbl.Text = TIPRATE1.ToString("P0"); // Percent format with no decimals
            rate2Lbl.Text = TIPRATE2.ToString("P0");
            rate3Lbl.Text = TIPRATE3.ToString("P0");
        }
    }
}
