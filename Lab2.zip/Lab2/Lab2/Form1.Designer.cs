﻿namespace Lab2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameTxt = new System.Windows.Forms.TextBox();
            this.middleNameTxt = new System.Windows.Forms.TextBox();
            this.lastNameTxt = new System.Windows.Forms.TextBox();
            this.titleTxt = new System.Windows.Forms.TextBox();
            this.firstNameLbl = new System.Windows.Forms.Label();
            this.middleNameLbl = new System.Windows.Forms.Label();
            this.lastNameLbl = new System.Windows.Forms.Label();
            this.titleLbl = new System.Windows.Forms.Label();
            this.outputLbl = new System.Windows.Forms.Label();
            this.formatBtn1 = new System.Windows.Forms.Button();
            this.formatBtn2 = new System.Windows.Forms.Button();
            this.formatBtn3 = new System.Windows.Forms.Button();
            this.formatBtn4 = new System.Windows.Forms.Button();
            this.formatBtn5 = new System.Windows.Forms.Button();
            this.formatBtn6 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstNameTxt
            // 
            this.firstNameTxt.Location = new System.Drawing.Point(221, 12);
            this.firstNameTxt.Name = "firstNameTxt";
            this.firstNameTxt.Size = new System.Drawing.Size(100, 20);
            this.firstNameTxt.TabIndex = 0;
            // 
            // middleNameTxt
            // 
            this.middleNameTxt.Location = new System.Drawing.Point(221, 39);
            this.middleNameTxt.Name = "middleNameTxt";
            this.middleNameTxt.Size = new System.Drawing.Size(100, 20);
            this.middleNameTxt.TabIndex = 1;
            // 
            // lastNameTxt
            // 
            this.lastNameTxt.Location = new System.Drawing.Point(221, 66);
            this.lastNameTxt.Name = "lastNameTxt";
            this.lastNameTxt.Size = new System.Drawing.Size(100, 20);
            this.lastNameTxt.TabIndex = 2;
            // 
            // titleTxt
            // 
            this.titleTxt.Location = new System.Drawing.Point(221, 92);
            this.titleTxt.Name = "titleTxt";
            this.titleTxt.Size = new System.Drawing.Size(100, 20);
            this.titleTxt.TabIndex = 3;
            // 
            // firstNameLbl
            // 
            this.firstNameLbl.Location = new System.Drawing.Point(16, 12);
            this.firstNameLbl.Name = "firstNameLbl";
            this.firstNameLbl.Size = new System.Drawing.Size(190, 23);
            this.firstNameLbl.TabIndex = 4;
            this.firstNameLbl.Text = "First name: ";
            this.firstNameLbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // middleNameLbl
            // 
            this.middleNameLbl.Location = new System.Drawing.Point(16, 39);
            this.middleNameLbl.Name = "middleNameLbl";
            this.middleNameLbl.Size = new System.Drawing.Size(190, 23);
            this.middleNameLbl.TabIndex = 5;
            this.middleNameLbl.Text = "Middle name:";
            this.middleNameLbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lastNameLbl
            // 
            this.lastNameLbl.Location = new System.Drawing.Point(16, 66);
            this.lastNameLbl.Name = "lastNameLbl";
            this.lastNameLbl.Size = new System.Drawing.Size(190, 13);
            this.lastNameLbl.TabIndex = 6;
            this.lastNameLbl.Text = "Last name:";
            this.lastNameLbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // titleLbl
            // 
            this.titleLbl.Location = new System.Drawing.Point(16, 93);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(190, 13);
            this.titleLbl.TabIndex = 7;
            this.titleLbl.Text = "Preferred title (Mr., Mrs., Ms., Dr., etc.):";
            this.titleLbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // outputLbl
            // 
            this.outputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLbl.Location = new System.Drawing.Point(16, 126);
            this.outputLbl.Name = "outputLbl";
            this.outputLbl.Size = new System.Drawing.Size(315, 23);
            this.outputLbl.TabIndex = 8;
            this.outputLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formatBtn1
            // 
            this.formatBtn1.Location = new System.Drawing.Point(12, 165);
            this.formatBtn1.Name = "formatBtn1";
            this.formatBtn1.Size = new System.Drawing.Size(75, 23);
            this.formatBtn1.TabIndex = 9;
            this.formatBtn1.Text = "Format 1";
            this.formatBtn1.UseVisualStyleBackColor = true;
            this.formatBtn1.Click += new System.EventHandler(this.formatBtn1_Click);
            // 
            // formatBtn2
            // 
            this.formatBtn2.Location = new System.Drawing.Point(93, 165);
            this.formatBtn2.Name = "formatBtn2";
            this.formatBtn2.Size = new System.Drawing.Size(75, 23);
            this.formatBtn2.TabIndex = 10;
            this.formatBtn2.Text = "Format 2";
            this.formatBtn2.UseVisualStyleBackColor = true;
            this.formatBtn2.Click += new System.EventHandler(this.formatBtn2_Click);
            // 
            // formatBtn3
            // 
            this.formatBtn3.Location = new System.Drawing.Point(174, 165);
            this.formatBtn3.Name = "formatBtn3";
            this.formatBtn3.Size = new System.Drawing.Size(75, 23);
            this.formatBtn3.TabIndex = 11;
            this.formatBtn3.Text = "Format 3";
            this.formatBtn3.UseVisualStyleBackColor = true;
            this.formatBtn3.Click += new System.EventHandler(this.formatBtn3_Click);
            // 
            // formatBtn4
            // 
            this.formatBtn4.Location = new System.Drawing.Point(256, 165);
            this.formatBtn4.Name = "formatBtn4";
            this.formatBtn4.Size = new System.Drawing.Size(75, 23);
            this.formatBtn4.TabIndex = 12;
            this.formatBtn4.Text = "Format 4";
            this.formatBtn4.UseVisualStyleBackColor = true;
            this.formatBtn4.Click += new System.EventHandler(this.formatBtn4_Click);
            // 
            // formatBtn5
            // 
            this.formatBtn5.Location = new System.Drawing.Point(53, 194);
            this.formatBtn5.Name = "formatBtn5";
            this.formatBtn5.Size = new System.Drawing.Size(75, 23);
            this.formatBtn5.TabIndex = 13;
            this.formatBtn5.Text = "Format 5";
            this.formatBtn5.UseVisualStyleBackColor = true;
            this.formatBtn5.Click += new System.EventHandler(this.formatBtn5_Click);
            // 
            // formatBtn6
            // 
            this.formatBtn6.Location = new System.Drawing.Point(210, 194);
            this.formatBtn6.Name = "formatBtn6";
            this.formatBtn6.Size = new System.Drawing.Size(75, 23);
            this.formatBtn6.TabIndex = 14;
            this.formatBtn6.Text = "Format 6";
            this.formatBtn6.UseVisualStyleBackColor = true;
            this.formatBtn6.Click += new System.EventHandler(this.formatBtn6_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 226);
            this.Controls.Add(this.formatBtn6);
            this.Controls.Add(this.formatBtn5);
            this.Controls.Add(this.formatBtn4);
            this.Controls.Add(this.formatBtn3);
            this.Controls.Add(this.formatBtn2);
            this.Controls.Add(this.formatBtn1);
            this.Controls.Add(this.outputLbl);
            this.Controls.Add(this.titleLbl);
            this.Controls.Add(this.lastNameLbl);
            this.Controls.Add(this.middleNameLbl);
            this.Controls.Add(this.firstNameLbl);
            this.Controls.Add(this.titleTxt);
            this.Controls.Add(this.lastNameTxt);
            this.Controls.Add(this.middleNameTxt);
            this.Controls.Add(this.firstNameTxt);
            this.Name = "Form1";
            this.Text = "Lab 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox firstNameTxt;
        private System.Windows.Forms.TextBox middleNameTxt;
        private System.Windows.Forms.TextBox lastNameTxt;
        private System.Windows.Forms.TextBox titleTxt;
        private System.Windows.Forms.Label firstNameLbl;
        private System.Windows.Forms.Label middleNameLbl;
        private System.Windows.Forms.Label lastNameLbl;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.Label outputLbl;
        private System.Windows.Forms.Button formatBtn1;
        private System.Windows.Forms.Button formatBtn2;
        private System.Windows.Forms.Button formatBtn3;
        private System.Windows.Forms.Button formatBtn4;
        private System.Windows.Forms.Button formatBtn5;
        private System.Windows.Forms.Button formatBtn6;
    }
}

