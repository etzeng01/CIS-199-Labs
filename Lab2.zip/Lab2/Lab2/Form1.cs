﻿// Lab 2
// CIS 199-01/-75
// Due: 2/2/2016
// By: Andrew L. Wright

// This program displays a form with text boxes for user
// to enter title, first, middle, and last names. Six
// buttons, each will display entered data in various
// formats.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Formats as Title First Middle Last
        private void formatBtn1_Click(object sender, EventArgs e)
        {
            string result; // Holds entered data in requested format

            result = titleTxt.Text + " " + firstNameTxt.Text + " " + middleNameTxt.Text + " " + lastNameTxt.Text;
            outputLbl.Text = result;
        }

        // Formats as First Middle Last
        private void formatBtn2_Click(object sender, EventArgs e)
        {
            string result; // Holds entered data in requested format

            result = firstNameTxt.Text + " " + middleNameTxt.Text + " " + lastNameTxt.Text;
            outputLbl.Text = result;
        }

        // Formats as First Last
        private void formatBtn3_Click(object sender, EventArgs e)
        {
            string result; // Holds entered data in requested format

            result = firstNameTxt.Text + " " + lastNameTxt.Text;
            outputLbl.Text = result;
        }

        // Formats as Last, First Middle, Title
        private void formatBtn4_Click(object sender, EventArgs e)
        {
            string result; // Holds entered data in requested format

            result = lastNameTxt.Text + ", " + firstNameTxt.Text + " " + middleNameTxt.Text + ", " + titleTxt.Text;
            outputLbl.Text = result;
        }

        // Formats as Last, First Middle
        private void formatBtn5_Click(object sender, EventArgs e)
        {
            string result; // Holds entered data in requested format

            result = lastNameTxt.Text + ", " + firstNameTxt.Text + " " + middleNameTxt.Text;
            outputLbl.Text = result;
        }

        // Formats as Last, First
        private void formatBtn6_Click(object sender, EventArgs e)
        {
            string result; // Holds entered data in requested format

            result = lastNameTxt.Text + ", " + firstNameTxt.Text;
            outputLbl.Text = result;
        }
    }
}
