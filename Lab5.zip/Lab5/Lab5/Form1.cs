﻿// Lab 5
// CIS 199-01/-75
// Due: 3/1/2016
// By: Andrew L. Wright

// This application allows the user to enter starting and
// ending points for counter-controlled repetition,
// specifying which loop control structure to use.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Run the requested counter-controlled loop
        private void runBtn_Click(object sender, EventArgs e)
        {
            int from; // Entered starting point
            int to;   // Entered ending point
            int i;    // Index for counting

            if (int.TryParse(fromTxt.Text, out from))
            {
                if (int.TryParse(toTxt.Text, out to))
                {
                    // Both TryParse statements worked
                    // Determine which loop was requested
                    if (whileRdoBtn.Checked) // while loop?
                    {
                        i = from;
                        while (i <= to)
                        {
                            outputListBox.Items.Add(i);
                            ++i;
                        }
                    }
                    else if (forRdoBtn.Checked) // for loop?
                    {
                        for (i = from; i <= to; ++i)
                        {
                            outputListBox.Items.Add(i);
                        }
                    }
                    else // do-while
                    {
                        i = from;
                        do
                        {
                            outputListBox.Items.Add(i);
                            ++i;
                        } while (i <= to);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid int for stopping point!");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid int for starting point!");
            }
        }

        // Clear the listbox
        private void clearBtn_Click(object sender, EventArgs e)
        {
            outputListBox.Items.Clear();
        }
    }
}
