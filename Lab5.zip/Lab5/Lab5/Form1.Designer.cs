﻿namespace Lab5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fromLbl = new System.Windows.Forms.Label();
            this.fromTxt = new System.Windows.Forms.TextBox();
            this.toLbl = new System.Windows.Forms.Label();
            this.toTxt = new System.Windows.Forms.TextBox();
            this.outputListBox = new System.Windows.Forms.ListBox();
            this.whileRdoBtn = new System.Windows.Forms.RadioButton();
            this.forRdoBtn = new System.Windows.Forms.RadioButton();
            this.doWhileRdoBtn = new System.Windows.Forms.RadioButton();
            this.runBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.loopUsingGrpBox = new System.Windows.Forms.GroupBox();
            this.loopUsingGrpBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // fromLbl
            // 
            this.fromLbl.AutoSize = true;
            this.fromLbl.Location = new System.Drawing.Point(13, 13);
            this.fromLbl.Name = "fromLbl";
            this.fromLbl.Size = new System.Drawing.Size(33, 13);
            this.fromLbl.TabIndex = 0;
            this.fromLbl.Text = "From:";
            // 
            // fromTxt
            // 
            this.fromTxt.Location = new System.Drawing.Point(16, 29);
            this.fromTxt.Name = "fromTxt";
            this.fromTxt.Size = new System.Drawing.Size(100, 20);
            this.fromTxt.TabIndex = 0;
            // 
            // toLbl
            // 
            this.toLbl.AutoSize = true;
            this.toLbl.Location = new System.Drawing.Point(12, 52);
            this.toLbl.Name = "toLbl";
            this.toLbl.Size = new System.Drawing.Size(23, 13);
            this.toLbl.TabIndex = 2;
            this.toLbl.Text = "To:";
            // 
            // toTxt
            // 
            this.toTxt.Location = new System.Drawing.Point(16, 68);
            this.toTxt.Name = "toTxt";
            this.toTxt.Size = new System.Drawing.Size(100, 20);
            this.toTxt.TabIndex = 1;
            // 
            // outputListBox
            // 
            this.outputListBox.FormattingEnabled = true;
            this.outputListBox.Location = new System.Drawing.Point(152, 13);
            this.outputListBox.Name = "outputListBox";
            this.outputListBox.Size = new System.Drawing.Size(120, 238);
            this.outputListBox.TabIndex = 5;
            // 
            // whileRdoBtn
            // 
            this.whileRdoBtn.AutoSize = true;
            this.whileRdoBtn.Checked = true;
            this.whileRdoBtn.Location = new System.Drawing.Point(9, 19);
            this.whileRdoBtn.Name = "whileRdoBtn";
            this.whileRdoBtn.Size = new System.Drawing.Size(49, 17);
            this.whileRdoBtn.TabIndex = 0;
            this.whileRdoBtn.TabStop = true;
            this.whileRdoBtn.Text = "while";
            this.whileRdoBtn.UseVisualStyleBackColor = true;
            // 
            // forRdoBtn
            // 
            this.forRdoBtn.AutoSize = true;
            this.forRdoBtn.Location = new System.Drawing.Point(9, 42);
            this.forRdoBtn.Name = "forRdoBtn";
            this.forRdoBtn.Size = new System.Drawing.Size(37, 17);
            this.forRdoBtn.TabIndex = 1;
            this.forRdoBtn.Text = "for";
            this.forRdoBtn.UseVisualStyleBackColor = true;
            // 
            // doWhileRdoBtn
            // 
            this.doWhileRdoBtn.AutoSize = true;
            this.doWhileRdoBtn.Location = new System.Drawing.Point(9, 65);
            this.doWhileRdoBtn.Name = "doWhileRdoBtn";
            this.doWhileRdoBtn.Size = new System.Drawing.Size(64, 17);
            this.doWhileRdoBtn.TabIndex = 2;
            this.doWhileRdoBtn.Text = "do-while";
            this.doWhileRdoBtn.UseVisualStyleBackColor = true;
            // 
            // runBtn
            // 
            this.runBtn.Location = new System.Drawing.Point(16, 200);
            this.runBtn.Name = "runBtn";
            this.runBtn.Size = new System.Drawing.Size(75, 23);
            this.runBtn.TabIndex = 3;
            this.runBtn.Text = "Run Loop";
            this.runBtn.UseVisualStyleBackColor = true;
            this.runBtn.Click += new System.EventHandler(this.runBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearBtn.Location = new System.Drawing.Point(16, 229);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 23);
            this.clearBtn.TabIndex = 4;
            this.clearBtn.Text = "Clear List";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // loopUsingGrpBox
            // 
            this.loopUsingGrpBox.Controls.Add(this.whileRdoBtn);
            this.loopUsingGrpBox.Controls.Add(this.forRdoBtn);
            this.loopUsingGrpBox.Controls.Add(this.doWhileRdoBtn);
            this.loopUsingGrpBox.Location = new System.Drawing.Point(16, 94);
            this.loopUsingGrpBox.Name = "loopUsingGrpBox";
            this.loopUsingGrpBox.Size = new System.Drawing.Size(100, 100);
            this.loopUsingGrpBox.TabIndex = 2;
            this.loopUsingGrpBox.TabStop = false;
            this.loopUsingGrpBox.Text = "Loop Using:";
            // 
            // Form1
            // 
            this.AcceptButton = this.runBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearBtn;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.loopUsingGrpBox);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.runBtn);
            this.Controls.Add(this.outputListBox);
            this.Controls.Add(this.toTxt);
            this.Controls.Add(this.toLbl);
            this.Controls.Add(this.fromTxt);
            this.Controls.Add(this.fromLbl);
            this.Name = "Form1";
            this.Text = "Lab 5";
            this.loopUsingGrpBox.ResumeLayout(false);
            this.loopUsingGrpBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fromLbl;
        private System.Windows.Forms.TextBox fromTxt;
        private System.Windows.Forms.Label toLbl;
        private System.Windows.Forms.TextBox toTxt;
        private System.Windows.Forms.ListBox outputListBox;
        private System.Windows.Forms.RadioButton whileRdoBtn;
        private System.Windows.Forms.RadioButton forRdoBtn;
        private System.Windows.Forms.RadioButton doWhileRdoBtn;
        private System.Windows.Forms.Button runBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.GroupBox loopUsingGrpBox;
    }
}

